package com.inducesmile.androidfoodordering.entities;

public class SuccessObject {

    private int success;

    public SuccessObject(int success) {
        this.success = success;
    }

    public int getSuccess() {
        return success;
    }
}
