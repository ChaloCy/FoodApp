package com.inducesmile.notification;


public class Helper {

    public static final String PATH_TO_SERVER_TOKEN_STORAGE = "PATH_TO_SERVER";

    public static final String TOKEN_TO_SERVER = "server_token";
}
